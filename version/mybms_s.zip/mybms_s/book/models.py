from django.db import models
from django.utils import timezone


class Publisher(models.Model):
    '''
    出版社类
    '''
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=32)

    def __str__(self):
        return self.name


class Book(models.Model):
    '''
    书类
    '''
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=32)
    price = models.DecimalField(max_digits=8,decimal_places=2)
    publish_date = models.DateTimeField(default=timezone.now())

    publisher = models.ForeignKey(to='Publisher',on_delete=models.CASCADE)

    def __str__(self):
        return self.title


class Author(models.Model):
    '''
    作者类
    '''
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=16)

    books = models.ManyToManyField(to='Book',related_name='authors')

    detail = models.OneToOneField(to='AuthorDetail',null=True,on_delete=models.CASCADE)

    def __str__(self):
        return self.name


class AuthorDetail(models.Model):
    '''
    作者详情
    '''
    age = models.IntegerField()
    addr = models.TextField()


class UserInfo(models.Model):
    '''
    登录注册的用户信息
    '''
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=16)
    pwd = models.CharField(max_length=32)
